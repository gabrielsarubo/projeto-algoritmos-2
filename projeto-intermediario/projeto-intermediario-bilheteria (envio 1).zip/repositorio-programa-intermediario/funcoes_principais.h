#ifndef _FUNCOES_PRINCIPAIS_H_
#define _FUNCOES_PRINCIPAIS_H_

/* ASSINATURA DAS FUNCOES PRINCIPAIS */
void reservarBilhete(FILMES *, BILHETES *, int *, int *, int *);
void buscarBilhete(FILMES *, BILHETES *, int *, int *, int *);
void addFilme(FILMES *, int *);
void mostrarListaFilmes(FILMES *, int *);

#endif